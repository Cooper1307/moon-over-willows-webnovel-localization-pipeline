# 任务：把 5 章中文原文逐段译成英文

你收到 91–95 章的中文原文（`03_SOURCE/ALL_SOURCE.md`，按 `#CH N` 分章，每行一段）。
为每一章输出一份**逐段英文**：每段一行，行数与中文段数严格相等。

## 一、输出格式（机器要自动切分，必须严格）
1. 每章以 `#CH <章号>` 单独一行开始，紧跟 `#TITLE: <英文题名>` 一行，之后每行一段英文。
2. 章与章之间只靠 `#CH` 分隔。**禁止**代码围栏（```）、`<PARA ...>` 锚点、`**Paragraph 3:**`/`P3.`/`3)` 之类编号标签、markdown 列表符号。
3. 段落与中文原文**严格 1:1**：不合并、不拆分、不补写、不漏译。中文段数见 `MANIFEST.json`。
4. 每段英文里不要嵌入中文译文；但原文字形解释（如 `the character "Xun" (寻， meaning "to seek")`）和成对弯引号 `“ ”` 是合法内容，**禁止清除**。
5. 所有章输出完后写 `## 译法建议`，格式 `中文原词 | 你采用的英文 | 理由（一句话）`；没有就写"无"。

## 二、翻译红线
- 优先级：**忠实原文 > 术语锁 > 跨章一致 > 表达自然**。
- 题材：宋代古装穿越，保留中国文化身份；句法节奏彻底英语化（这是网文，短句、口语、有画面感）。
- **不可西化**：朝代 the Song、都城 Lin'an、真实人名 Zhu Shuzhen/Qianli Xun/Qiao Wenxian/Kuqiao、词牌拼音、官制（官家=His Majesty、嬷嬷=Matron、郡主=Princess Jiahe）、和离（独立制度词，首现给 ≤12 词内嵌解释）、度量（taels of silver）全部保留。禁 King/Queen/Duke/Marquis 换官制，禁 pounds/dollars 换算，禁 sonnet/ode 换词牌。
- 剧情承重位：第73章艳词是角色当场现作、没写完、旁人后加标题；首现按原文场景译（醉酒后主动坐怀），转述允许自然变体。不许写成完整传世名词。
- **不许补史实**：全书原文没有"父母焚稿/焚毁/断肠集"，不得写进译文正文；翻译只翻原文已有的东西。
- 前 3 章不加宋代背景介绍或 TN 注（原文前 2 章本身就是现代网暴/都市）。
- 诗词遇 `[POEM]/[PUZZLE]` 标记 → 停机回报，不硬翻；其余诗词用权威译本并标 `[TN: Translated by …]`，自译标 `[TN: Translator's rendering]`。

## 三、术语表怎么用
`01_GLOSSARY.md` 是**全量历史术语表，整份可推翻**。状态列是脚本按频次自动升级的，不是命令。
更地道的译法直接用，并在「译法建议」回传。不要机械替换牺牲译文。
`02_CONTEXT.md` 是人工确认过的既定事实，**优先级高于术语表的 `[建议]` 状态，但低于忠实原文**。

## 四、写作标准
- 去 AI 痕迹：禁 delve/leverage/pivotal/myriad/tapestry/testament 等；em dash 不过量；三段式排比仅限原文刻意设计。
- `-ly` 只禁"副词修饰动作动词"的弱填充；`really/perfectly/truly/entirely/miraculously` 允许。
- 不要为了本地扫描脚本的历史句长/段长阈值改写或拆段——段落 1:1 更高优先。
- 角色音色靠语气区分：女主 sassy/modern、男主 composed/protective、女配 meek/dramatic。

## 五、输出前自检（逐条过一遍）
- [ ] 章数 = 5，章号 91–95 全齐
- [ ] 每章英文段数 = MANIFEST 里该章 expected_paras
- [ ] 无代码围栏、无段落编号、无 `#CH` 残留在正文
- [ ] 每章都有 `#TITLE:`
- [ ] 末尾有「## 译法建议」（哪怕写"无"）
- [ ] 角色名拼写与 02_CONTEXT.md 完全一致，无变体

附录文件：`00_RULES.md`（规则）· `01_GLOSSARY.md`（术语）· `02_CONTEXT.md`（既定事实）· `03_SOURCE/ALL_SOURCE.md`（原文）· `04_OUTPUT_TEMPLATE.txt`（格式样例）· `MANIFEST.json`（段数）。
AI Studio 用法：把 `SYSTEM.txt` 全文贴进"指令/系统提示"栏，把 `PROMPT.md` 全文贴进对话框，上传/粘贴 `03_SOURCE/ALL_SOURCE.md` 与其余 md（或把几个文件依次贴进同一条消息）。选 Gemini 4 Neon，思考档位调中低、输出额度留足。
